# Personal Finance Advisor Bot

A ready-to-run student capstone project that helps users record income and expenses, visualize spending, build a monthly budget, and export a report.

## Features
- Dashboard with income, expenses, remaining balance, and savings rate
- Expense breakdown by category and income-vs-expense chart
- Add and edit transactions
- Rule-based spending insights
- Monthly 50/30/20-style budget planner with editable percentages
- Savings-goal timeline estimate
- Downloadable CSV transaction data and text summary report
- Sample transactions so the demo looks populated on first launch

## Tech stack
- Python
- Streamlit (web UI)
- Pandas (transaction processing)
- Plotly (interactive charts)

## Run locally
1. Install Python 3.10 or newer.
2. Download or clone this repository.
3. Open a terminal in the project folder.
4. Create a virtual environment (recommended):
   - Windows: `python -m venv .venv` then `.venv\\Scripts\\activate`
   - macOS/Linux: `python3 -m venv .venv` then `source .venv/bin/activate`
5. Install dependencies: `pip install -r requirements.txt`
6. Start the app: `streamlit run app.py`
7. Open the local URL shown in the terminal, usually `http://localhost:8501`.

## Deploy a public demo with Streamlit Community Cloud
1. Push the project files to a **public GitHub repository**.
2. Sign in to Streamlit Community Cloud using GitHub.
3. Choose **Create app**, select your repository, branch (`main`), and main file path (`app.py`).
4. Click **Deploy** and wait for the build to finish.
5. Copy the public app URL and test it in an incognito/private browser window while logged out.
6. In your submission document, include the GitHub repository URL and the deployed demo URL. Do not share a private/local `localhost` URL.

## Suggested repository structure
```text
personal-finance-advisor-bot/
├── app.py
├── requirements.txt
├── README.md
├── PROJECT_REPORT.md
├── .gitignore
└── screenshots/
    └── (add screenshots of your actual running app)
```

## Limitations and responsible use
- This prototype does not connect to bank accounts and does not store user data in a permanent database.
- Transactions are held in the active app session; they may reset when the session restarts.
- Insights are simple rules, not a trained machine-learning model or financial advice.
- Do not enter bank passwords, account numbers, or sensitive personal information.

## Demo checklist
- [ ] App opens without an error
- [ ] Dashboard charts are visible
- [ ] Add one income transaction
- [ ] Add one expense transaction
- [ ] Budget planner calculates category amounts
- [ ] CSV and summary downloads work
- [ ] Public demo opens when logged out
- [ ] README and project report are included
