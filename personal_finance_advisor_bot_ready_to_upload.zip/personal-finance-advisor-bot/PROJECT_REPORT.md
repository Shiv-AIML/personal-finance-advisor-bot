# Capstone Project Report: Personal Finance Advisor Bot

## 1. Abstract
The Personal Finance Advisor Bot is a web-based prototype designed to make basic personal money management easier. Users can record income and expenses, view spending summaries, create a monthly budget, estimate progress toward a savings goal, and download a report. The application uses Python for logic, Streamlit for the interface, Pandas for data manipulation, and Plotly for interactive visualizations.

## 2. Problem statement
Many students and early-career earners track spending informally or not at all. This makes it difficult to understand where money goes, compare spending with income, or set realistic savings targets. A simple, accessible tool can help users organize their own records and notice basic patterns.

## 3. Objectives
- Provide a simple interface for entering income and expenses.
- Summarize income, spending, balance, and savings rate.
- Visualize expenses by category.
- Offer transparent rule-based spending insights.
- Support a configurable monthly budget and savings goal.
- Export transactions and a summary for review.

## 4. Proposed solution
The app keeps a transaction table with date, type, category, amount, and note. The dashboard calculates totals from the table and displays charts. A rule-based insight section flags overspending or a low savings rate. The budget planner allocates expected income according to user-selected percentages. Users can export a CSV and a plain-text summary.

## 5. System requirements
**Software:** Python 3.10+, Streamlit, Pandas, Plotly, web browser, GitHub account, Streamlit Community Cloud account for hosting.

**Hardware:** Any modern laptop/desktop capable of running Python; internet access is needed for cloud deployment.

## 6. Modules
1. **Transaction management:** add, edit, and clear income/expense records.
2. **Dashboard:** calculate totals and render charts.
3. **Insight engine:** apply transparent rules to the entered data.
4. **Budget planner:** allocate monthly income to needs, wants, and savings.
5. **Report export:** download CSV transactions and a text summary.

## 7. Methodology / algorithms
Let income be the sum of all rows whose type is Income and expenses be the sum of all rows whose type is Expense.

- Balance = Income − Expenses
- Savings rate (%) = (Balance / Income) × 100, when income is greater than zero
- Category spending = sum of expense amounts grouped by category
- Budget allocation = expected monthly income × selected percentage / 100
- Estimated months to goal = savings goal / monthly savings target, when the target is positive

The insight engine warns when expenses exceed income and suggests reviewing spending when the savings rate is below 20%. These are simple decision rules, not machine learning.

## 8. Testing plan
| Test | Action | Expected result |
|---|---|---|
| T1 | Launch app | Dashboard appears with sample records |
| T2 | Add income | Income total increases |
| T3 | Add expense | Expense total and category chart update |
| T4 | Set budget percentages | Budget amounts recalculate |
| T5 | Set savings goal | Approximate months are displayed when target > 0 |
| T6 | Download CSV | CSV file downloads |
| T7 | Open deployed link in private browser | App is accessible without repository permissions |

Record actual results and add screenshots after testing the deployed app.

## 9. Results
The prototype demonstrates transaction entry, summary metrics, visual spending analysis, rule-based insights, budget planning, and report downloads. Final screenshots and measured test results should be added after the app is run and deployed.

## 10. Limitations and future scope
Current data is session-based and is not permanently stored. The insight engine uses rules and should not be described as a trained AI model. Future work could include authentication, a database, recurring transactions, budget alerts, CSV import, forecasting from historical records, and explainable machine-learning features with appropriate evaluation.

## 11. Conclusion
The project provides a practical starting point for digital personal-finance tracking. It demonstrates a complete working web prototype and a reproducible deployment path. It is intended for educational use and does not replace professional financial advice.

## 12. References
- Python: https://www.python.org/
- Streamlit documentation: https://docs.streamlit.io/
- Pandas documentation: https://pandas.pydata.org/docs/
- Plotly Python documentation: https://plotly.com/python/
- Streamlit Community Cloud: https://streamlit.io/cloud
