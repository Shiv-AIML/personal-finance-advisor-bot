import streamlit as st
import pandas as pd
import plotly.express as px
from datetime import date
from io import StringIO

st.set_page_config(page_title="Personal Finance Advisor", page_icon="💰", layout="wide")
st.title("💰 Personal Finance Advisor Bot")
st.caption("A student capstone demo for budgeting, expense tracking, and savings insights.")
st.info("Demo app: use sample data or enter your own figures. This is educational guidance, not professional financial advice.")

if "transactions" not in st.session_state:
    st.session_state.transactions = pd.DataFrame([
        {"Date": str(date.today()), "Type": "Income", "Category": "Salary / Allowance", "Amount": 18000.0, "Note": "Monthly income"},
        {"Date": str(date.today()), "Type": "Expense", "Category": "Food", "Amount": 2500.0, "Note": "Groceries and meals"},
        {"Date": str(date.today()), "Type": "Expense", "Category": "Transport", "Amount": 1200.0, "Note": "Bus and fuel"},
        {"Date": str(date.today()), "Type": "Expense", "Category": "Education", "Amount": 1800.0, "Note": "Books and supplies"},
        {"Date": str(date.today()), "Type": "Expense", "Category": "Entertainment", "Amount": 900.0, "Note": "Movies and subscriptions"},
        {"Date": str(date.today()), "Type": "Expense", "Category": "Food", "Amount": 1600.0, "Note": "Eating out"},
    ])

with st.sidebar:
    st.header("Add transaction")
    with st.form("transaction_form", clear_on_submit=True):
        txn_date = st.date_input("Date", value=date.today())
        txn_type = st.selectbox("Type", ["Expense", "Income"])
        category_options = ["Food", "Transport", "Housing", "Education", "Health", "Entertainment", "Shopping", "Bills", "Savings", "Salary / Allowance", "Freelance", "Other"]
        category = st.selectbox("Category", category_options)
        amount = st.number_input("Amount (₹)", min_value=1.0, value=100.0, step=50.0)
        note = st.text_input("Note (optional)")
        submitted = st.form_submit_button("Add transaction", use_container_width=True)
        if submitted:
            new = pd.DataFrame([{"Date": str(txn_date), "Type": txn_type, "Category": category, "Amount": float(amount), "Note": note}])
            st.session_state.transactions = pd.concat([st.session_state.transactions, new], ignore_index=True)
            st.success("Transaction added.")

tab1, tab2, tab3, tab4 = st.tabs(["📊 Dashboard", "🧾 Transactions", "🎯 Budget planner", "📄 Export report"])
df = st.session_state.transactions.copy()
income = df.loc[df.Type == "Income", "Amount"].sum()
expenses = df.loc[df.Type == "Expense", "Amount"].sum()
balance = income - expenses
savings_rate = (balance / income * 100) if income else 0

with tab1:
    a,b,c,d = st.columns(4)
    a.metric("Total income", f"₹{income:,.0f}")
    b.metric("Total expenses", f"₹{expenses:,.0f}")
    c.metric("Balance", f"₹{balance:,.0f}", delta=f"{balance:,.0f}")
    d.metric("Savings rate", f"{savings_rate:.1f}%")
    left,right = st.columns(2)
    expense_df = df[df.Type == "Expense"]
    if not expense_df.empty:
        with left:
            st.subheader("Expenses by category")
            by_cat = expense_df.groupby("Category", as_index=False)["Amount"].sum().sort_values("Amount", ascending=False)
            st.plotly_chart(px.pie(by_cat, names="Category", values="Amount", hole=.45), use_container_width=True)
        with right:
            st.subheader("Income vs expenses")
            totals = pd.DataFrame({"Type":["Income","Expense"], "Amount":[income,expenses]})
            st.plotly_chart(px.bar(totals, x="Type", y="Amount", text_auto=".2s"), use_container_width=True)
    st.subheader("Smart insights")
    if income <= 0:
        st.warning("Add an income transaction to generate a meaningful budget.")
    else:
        if expenses > income:
            st.error(f"You are spending ₹{expenses-income:,.0f} more than your recorded income. Review non-essential expenses first.")
        elif savings_rate < 20:
            st.warning("Your recorded savings rate is below 20%. Try setting a small automatic savings target and reviewing recurring purchases.")
        else:
            st.success("Good progress: your recorded balance is positive and savings rate is at least 20%. Keep tracking consistently.")
        biggest = expense_df.groupby("Category")["Amount"].sum().sort_values(ascending=False) if not expense_df.empty else pd.Series(dtype=float)
        if len(biggest):
            st.write(f"Your largest expense category is **{biggest.index[0]}** (₹{biggest.iloc[0]:,.0f}). Check whether a realistic limit would help.")
        st.caption("Insights use only the transactions entered in this demo; they are not predictions or guarantees.")

with tab2:
    st.subheader("All transactions")
    edited = st.data_editor(df, num_rows="dynamic", use_container_width=True, key="editor")
    if st.button("Save table edits"):
        st.session_state.transactions = edited
        st.success("Table saved for this session.")
    if st.button("Clear all transactions"):
        st.session_state.transactions = pd.DataFrame(columns=["Date","Type","Category","Amount","Note"])
        st.rerun()

with tab3:
    st.subheader("Monthly budget planner")
    monthly_income = st.number_input("Expected monthly income (₹)", min_value=0.0, value=float(income), step=500.0)
    needs_pct = st.slider("Needs (%)", 0, 100, 50)
    wants_pct = st.slider("Wants (%)", 0, 100, 30)
    savings_pct = st.slider("Savings (%)", 0, 100, 20)
    total_pct = needs_pct + wants_pct + savings_pct
    if total_pct != 100:
        st.warning(f"Your percentages add up to {total_pct}%. Adjust them to equal 100% for a complete plan.")
    p,q,r = st.columns(3)
    p.metric("Needs budget", f"₹{monthly_income*needs_pct/100:,.0f}")
    q.metric("Wants budget", f"₹{monthly_income*wants_pct/100:,.0f}")
    r.metric("Savings target", f"₹{monthly_income*savings_pct/100:,.0f}")
    st.write("A common starting point is 50/30/20, but your situation may require different proportions.")
    goal = st.number_input("Savings goal (₹)", min_value=0.0, value=10000.0, step=1000.0)
    monthly_save = monthly_income*savings_pct/100
    if goal > 0 and monthly_save > 0:
        st.write(f"At this target, reaching ₹{goal:,.0f} could take about **{goal/monthly_save:.1f} months**, assuming income and savings stay constant.")

with tab4:
    st.subheader("Download your report")
    st.write("Export the transaction table as CSV for your project submission or further analysis.")
    csv = df.to_csv(index=False).encode("utf-8")
    st.download_button("⬇️ Download transactions CSV", csv, "finance_transactions.csv", "text/csv")
    report = f"""PERSONAL FINANCE ADVISOR BOT — DEMO REPORT
Generated: {date.today().isoformat()}

Total income: ₹{income:,.2f}
Total expenses: ₹{expenses:,.2f}
Balance: ₹{balance:,.2f}
Savings rate: {savings_rate:.1f}%

Transactions recorded: {len(df)}

This report is based only on data entered into the demo application.
It is educational and is not professional financial advice.
"""
    st.download_button("⬇️ Download summary report", report, "finance_summary.txt", "text/plain")
    st.markdown("**Demo privacy note:** data is stored in the current Streamlit session and is not connected to a bank account.")
st.divider()
st.caption("Built with Python, Streamlit, Pandas, and Plotly • Capstone project prototype")
